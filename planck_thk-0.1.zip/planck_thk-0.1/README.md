# Planck Through Hole Kit

Gerbers and BOMs have been moved to releases:

https://github.com/olkb/planck_thk/releases
